package Fishing;

public class fishingrod {
	
	String RodName;
	String Normal ="Normal";
	String Rare ="Rare";
	String Unique ="Unique";
	
}
