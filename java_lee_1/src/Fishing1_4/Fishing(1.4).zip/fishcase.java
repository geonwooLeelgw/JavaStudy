package Fishing;

public class fishcase {
	 String fishname;
	 int fishnum;
	 int fishprice;

public fishcase(String fishname,int fishnum,int fishprice) {
	this.fishname=fishname;
	this.fishnum=fishnum;
	this.fishprice=fishprice;
}


}
