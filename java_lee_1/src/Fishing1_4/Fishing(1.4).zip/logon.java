package Fishing;

public class logon {
	 String logID;
 String logPassword;
	static String necname;
	public logon(String logID,String logPassword,String necname) {
		this.logID=logID;
		this.logPassword=logPassword;
		this.necname=necname;
	}
}
